

/** @var ${TYPE_HINT} */
